Oculus LCD Screen Cleaning Aid/Utility v0.1.2

This LCD cleaning utility is for the meticulous, who don't enjoy wasting time and want the best end result for their effort.

This application is designed to help improve your success rate when trying to clean dust off of your LCD screen.

I decided to write this app after getting annoyed at cleaning my LCD. I started to use MSpaint so that I would have a nice white background to scour the area of dust. I would draw circles on the screen where I found dust, because as you may have noticed, where you see dust with the lens on isn't quite where you can expect to find it once you take the lens off. And let's be honest the least amount of downtime with the lenses off the better, to prevent new dust from invading our territory.  

After using paint for a bit I figured I could write something quickly in unity that would help make this process even better.

Controls:

All you need to know is left click places a dot, right click clears all dots, and space cycles through the views.

On the left screen you get red dots, on the right screen you get cyan dots.

When the mouse is on the left screen you see a red �L�.
When the mouse is on the right screen you see a cyan �R�.

The screen cycles as follows:

Instructions
White screen
Shutter Screen - the opposite side of the scren from the mouse will be blacked out. I added this because it's much easier than closing one eye and throwing focus off.
Black screen � all dots will turn white for clarity
Black screen � all dots will increase in size to inspect surrounding area
Repeat

Use as you see fit, there is no intended order of operations. I just found these views work nice for me.
Ideally I like to mark the dirt, reinspect with both eyes open, then alternating closed. 
Clean, right click to remove dots, reinspect.

I beg for suggestions. Please comment on the Oculus forum post or on the comments at Daggasoft.com.

Thanks,

https://app.box.com/s/4f51v4plobrt4t715xoz